#include "support.h"

/*
 * Please be sure to fill in this struct right away!
 */
struct team_t team =
{
  "Yaodong Sheng", /* first member name, e.g., Michael Spear */
  "yas616@lehigh.edu", /* first member email, e.g., mfs409@lehigh.edu */
  "Tianze Wang", /* second member name, e.g., Michael Spear */
  "tiw316@lehigh.edu"  /* second member email, e.g., mfs409@lehigh.edu */
};
